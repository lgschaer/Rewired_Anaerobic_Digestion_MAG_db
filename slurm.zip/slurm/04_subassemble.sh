#!/bin/bash

#SBATCH --nodes=1                    # Number of nodes (usually 1 for metagenome assembly)
#SBATCH --ntasks=20                  # Number of tasks (CPU cores, one per sample if running in parallel)
#SBATCH --cpus-per-task=4            # Number of CPU cores per task (adjust according to your resource needs)
#SBATCH --mem=400G                   # Memory allocated for the job (adjust as needed)
#SBATCH --time=6-00:00:00            # Max runtime (DD-HH:MM:SS)
#SBATCH --nodelist=node004           # Specify the node
#SBATCH --partition=week-long-cpu    # Specify the partition

module load slurm
srun --pty bash
conda init
conda activate assemble

cd ../trimmed_reads/


# ------------------------------------------------------
# Reformat trimmed reads to 25% and 50% subset for each sample
# ------------------------------------------------------

# List of sample names (excluding file extensions)
samples=("AFW_S631" "BFW_S632" "BM_S633")

# Loop through each sample to generate subsets at 25% and 50% sampling rates
for sample in "${samples[@]}"
do
    # Generate 25% subset with 3 unique copies
    for i in {1..3}
    do
        reformat.sh in1=${sample}_trimmed_R1.fastq in2=${sample}_trimmed_R2.fastq \
            out1=${sample}_trimmed_R1_25pcnt_copy${i}.fastq out2=${sample}_trimmed_R2_25pcnt_copy${i}.fastq \
            samplerate=0.25 -sampleseed=$((1234 + i))
        
        # Print message indicating the 25% subset copy is generated
        echo "25% subset (copy ${i}) for ${sample} generated."
    done

    # Generate 50% subset with 3 unique copies
    for i in {1..3}
    do
        reformat.sh in1=${sample}_trimmed_R1.fastq in2=${sample}_trimmed_R2.fastq \
            out1=${sample}_trimmed_R1_50pcnt_copy${i}.fastq out2=${sample}_trimmed_R2_50pcnt_copy${i}.fastq \
            samplerate=0.50 -sampleseed=$((5678 + i))
        
        # Print message indicating the 50% subset copy is generated
        echo "50% subset (copy ${i}) for ${sample} generated."
    done
done

# ------------------------------------------------------
# Notes:
# - The reformat.sh command subsets the input fastq files (R1 and R2) to 25% and 50%.
# - The 'samplerate=0.25' and 'samplerate=0.50' ensure 25% and 50% subsets, respectively.
# - The '-sampleseed' flag ensures different random subsets are generated for each copy.
# ------------------------------------------------------


# ------------------------------------------------------
# Run MEGAHIT assembly for 25% and 50% subset files for each sample
# ------------------------------------------------------

# List of sample names (excluding file extensions)
samples=("AFW_S631" "BFW_S632" "BM_S633")

# MEGAHIT commands for AFW_S631
megahit \
    -1 AFW_S631_trimmed_R1_25pcnt_copy1.fastq \
    -2 AFW_S631_trimmed_R2_25pcnt_copy1.fastq \
    --k-min 31 \
    --k-max 121 \
    --k-step 10 \
    --mem-flag 1 \
    -m 429496729600 \
    -t 20 \
    -o AFW_S631_trimmed_25pcnt_copy1_megahit_output

echo "MEGAHIT assembly for AFW_S631_trimmed_R1_25pcnt_copy1 completed."

megahit \
    -1 AFW_S631_trimmed_R1_25pcnt_copy2.fastq \
    -2 AFW_S631_trimmed_R2_25pcnt_copy2.fastq \
    --k-min 31 \
    --k-max 121 \
    --k-step 10 \
    --mem-flag 1 \
    -m 429496729600 \
    -t 20 \
    -o AFW_S631_trimmed_25pcnt_copy2_megahit_output

echo "MEGAHIT assembly for AFW_S631_trimmed_R1_25pcnt_copy2 completed."

megahit \
    -1 AFW_S631_trimmed_R1_25pcnt_copy3.fastq \
    -2 AFW_S631_trimmed_R2_25pcnt_copy3.fastq \
    --k-min 31 \
    --k-max 121 \
    --k-step 10 \
    --mem-flag 1 \
    -m 429496729600 \
    -t 20 \
    -o AFW_S631_trimmed_25pcnt_copy3_megahit_output

echo "MEGAHIT assembly for AFW_S631_trimmed_R1_25pcnt_copy3 completed."

megahit \
    -1 AFW_S631_trimmed_R1_50pcnt_copy1.fastq \
    -2 AFW_S631_trimmed_R2_50pcnt_copy1.fastq \
    --k-min 31 \
    --k-max 121 \
    --k-step 10 \
    --mem-flag 1 \
    -m 429496729600 \
    -t 20 \
    -o AFW_S631_trimmed_50pcnt_copy1_megahit_output

echo "MEGAHIT assembly for AFW_S631_trimmed_R1_50pcnt_copy1 completed."

megahit \
    -1 AFW_S631_trimmed_R1_50pcnt_copy2.fastq \
    -2 AFW_S631_trimmed_R2_50pcnt_copy2.fastq \
    --k-min 31 \
    --k-max 121 \
    --k-step 10 \
    --mem-flag 1 \
    -m 429496729600 \
    -t 20 \
    -o AFW_S631_trimmed_50pcnt_copy2_megahit_output

echo "MEGAHIT assembly for AFW_S631_trimmed_R1_50pcnt_copy2 completed."

megahit \
    -1 AFW_S631_trimmed_R1_50pcnt_copy3.fastq \
    -2 AFW_S631_trimmed_R2_50pcnt_copy3.fastq \
    --k-min 31 \
    --k-max 121 \
    --k-step 10 \
    --mem-flag 1 \
    -m 429496729600 \
    -t 20 \
    -o AFW_S631_trimmed_50pcnt_copy3_megahit_output

echo "MEGAHIT assembly for AFW_S631_trimmed_R1_50pcnt_copy3 completed."

# MEGAHIT commands for BFW_S632
megahit \
    -1 BFW_S632_trimmed_R1_25pcnt_copy1.fastq \
    -2 BFW_S632_trimmed_R2_25pcnt_copy1.fastq \
    --k-min 31 \
    --k-max 121 \
    --k-step 10 \
    --mem-flag 1 \
    -m 429496729600 \
    -t 20 \
    -o BFW_S632_trimmed_25pcnt_copy1_megahit_output

echo "MEGAHIT assembly for BFW_S632_trimmed_R1_25pcnt_copy1 completed."

megahit \
    -1 BFW_S632_trimmed_R1_25pcnt_copy2.fastq \
    -2 BFW_S632_trimmed_R2_25pcnt_copy2.fastq \
    --k-min 31 \
    --k-max 121 \
    --k-step 10 \
    --mem-flag 1 \
    -m 429496729600 \
    -t 20 \
    -o BFW_S632_trimmed_25pcnt_copy2_megahit_output

echo "MEGAHIT assembly for BFW_S632_trimmed_R1_25pcnt_copy2 completed."

megahit \
    -1 BFW_S632_trimmed_R1_25pcnt_copy3.fastq \
    -2 BFW_S632_trimmed_R2_25pcnt_copy3.fastq \
    --k-min 31 \
    --k-max 121 \
    --k-step 10 \
    --mem-flag 1 \
    -m 429496729600 \
    -t 20 \
    -o BFW_S632_trimmed_25pcnt_copy3_megahit_output

echo "MEGAHIT assembly for BFW_S632_trimmed_R1_25pcnt_copy3 completed."

megahit \
    -1 BFW_S632_trimmed_R1_50pcnt_copy1.fastq \
    -2 BFW_S632_trimmed_R2_50pcnt_copy1.fastq \
    --k-min 31 \
    --k-max 121 \
    --k-step 10 \
    --mem-flag 1 \
    -m 429496729600 \
    -t 20 \
    -o BFW_S632_trimmed_50pcnt_copy1_megahit_output

echo "MEGAHIT assembly for BFW_S632_trimmed_R1_50pcnt_copy1 completed."

megahit \
    -1 BFW_S632_trimmed_R1_50pcnt_copy2.fastq \
    -2 BFW_S632_trimmed_R2_50pcnt_copy2.fastq \
    --k-min 31 \
    --k-max 121 \
    --k-step 10 \
    --mem-flag 1 \
    -m 429496729600 \
    -t 20 \
    -o BFW_S632_trimmed_50pcnt_copy2_megahit_output

echo "MEGAHIT assembly for BFW_S632_trimmed_R1_50pcnt_copy2 completed."

megahit \
    -1 BFW_S632_trimmed_R1_50pcnt_copy3.fastq \
    -2 BFW_S632_trimmed_R2_50pcnt_copy3.fastq \
    --k-min 31 \
    --k-max 121 \
    --k-step 10 \
    --mem-flag 1 \
    -m 429496729600 \
    -t 20 \
    -o BFW_S632_trimmed_50pcnt_copy3_megahit_output

echo "MEGAHIT assembly for BFW_S632_trimmed_R1_50pcnt_copy3 completed."

# MEGAHIT commands for BM_S633
megahit \
    -1 BM_S633_trimmed_R1_25pcnt_copy1.fastq \
    -2 BM_S633_trimmed_R2_25pcnt_copy1.fastq \
    --k-min 31 \
    --k-max 121 \
    --k-step 10 \
    --mem-flag 1 \
    -m 429496729600 \
    -t 20 \
    -o BM_S633_trimmed_25pcnt_copy1_megahit_output

echo "MEGAHIT assembly for BM_S633_trimmed_R1_25pcnt_copy1 completed."

megahit \
    -1 BM_S633_trimmed_R1_25pcnt_copy2.fastq \
    -2 BM_S633_trimmed_R2_25pcnt_copy2.fastq \
    --k-min 31 \
    --k-max 121 \
    --k-step 10 \
    --mem-flag 1 \
    -m 429496729600 \
    -t 20 \
    -o BM_S633_trimmed_25pcnt_copy2_megahit_output

echo "MEGAHIT assembly for BM_S633_trimmed_R1_25pcnt_copy2 completed."

megahit \
    -1 BM_S633_trimmed_R1_25pcnt_copy3.fastq \
    -2 BM_S633_trimmed_R2_25pcnt_copy3.fastq \
    --k-min 31 \
    --k-max 121 \
    --k-step 10 \
    --mem-flag 1 \
    -m 429496729600 \
    -t 20 \
    -o BM_S633_trimmed_25pcnt_copy3_megahit_output

echo "MEGAHIT assembly for BM_S633_trimmed_R1_25pcnt_copy3 completed."

megahit \
    -1 BM_S633_trimmed_R1_50pcnt_copy1.fastq \
    -2 BM_S633_trimmed_R2_50pcnt_copy1.fastq \
    --k-min 31 \
    --k-max 121 \
    --k-step 10 \
    --mem-flag 1 \
    -m 429496729600 \
    -t 20 \
    -o BM_S633_trimmed_50pcnt_copy1_megahit_output

echo "MEGAHIT assembly for BM_S633_trimmed_R1_50pcnt_copy1 completed."

megahit \
    -1 BM_S633_trimmed_R1_50pcnt_copy2.fastq \
    -2 BM_S633_trimmed_R2_50pcnt_copy2.fastq \
    --k-min 31 \
    --k-max 121 \
    --k-step 10 \
    --mem-flag 1 \
    -m 429496729600 \
    -t 20 \
    -o BM_S633_trimmed_50pcnt_copy2_megahit_output

echo "MEGAHIT assembly for BM_S633_trimmed_R1_50pcnt_copy2 completed."

megahit \
    -1 BM_S633_trimmed_R1_50pcnt_copy3.fastq \
    -2 BM_S633_trimmed_R2_50pcnt_copy3.fastq \
    --k-min 31 \
    --k-max 121 \
    --k-step 10 \
    --mem-flag 1 \
    -m 429496729600 \
    -t 20 \
    -o BM_S633_trimmed_50pcnt_copy3_megahit_output

echo "MEGAHIT assembly for BM_S633_trimmed_R1_50pcnt_copy3 completed."


# ------------------------------------------------------
# Notes:
# - Each MEGAHIT command will assemble the 25% and 50% subset files for each sample using different random seeds (copy1, copy2, copy3).
# - The output directory for each assembly is specified by the '-o' flag (e.g., ${sample}_trimmed_25pcnt_copy${i}_megahit_output).
# - The `--k-min 31 --k-max 121 --k-step 10` flags specify the range and step for k-mer sizes.
# - The `--mem-flag 1 -m 429496729600` flags allocate memory, and `-t 20` specifies 20 threads for multi-threading.
# ------------------------------------------------------
