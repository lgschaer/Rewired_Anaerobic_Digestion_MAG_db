#!/bin/bash

#SBATCH --nodes=1                    # Number of nodes (usually 1 for metagenome assembly)
#SBATCH --ntasks=20                  # Number of tasks (CPU cores, one per sample if running in parallel)
#SBATCH --cpus-per-task=4           # Number of CPU cores per task (adjust according to your resource needs)
#SBATCH --mem=400G                   # Memory allocated for the job (adjust as needed)
#SBATCH --time=6-00:00:00            # Max runtime (DD-HH:MM:SS)
#SBATCH --nodelist=node003           # Specify the node
#SBATCH --partition=week-long-cpu    # Specify the partition

module load slurm
srun --pty bash
conda init
conda activate assemble

cd ../trimmed_reads/

# ------------------------------------------------------
# Individual Assembly Commands for Each Sample
# ------------------------------------------------------

# AFW Sample Assembly
megahit -1 AFW_S631_trimmed_R1.fastq -2 AFW_S631_trimmed_R2.fastq -o AFW_assembly \
  --k-min 31 --k-max 121 --k-step 10 --mem-flag 1 -m 429496729600 -t 20

# BFW Sample Assembly
megahit -1 BFW_S632_trimmed_R1.fastq -2 BFW_S632_trimmed_R2.fastq -o BFW_assembly \
  --k-min 31 --k-max 121 --k-step 10 --mem-flag 1 -m 429496729600 -t 20

# BM Sample Assembly
megahit -1 BM_S633_trimmed_R1.fastq -2 BM_S633_trimmed_R2.fastq -o BM_assembly \
  --k-min 31 --k-max 121 --k-step 10 --mem-flag 1 -m 429496729600 -t 20


# ------------------------------------------------------
# Co-Assembly Commands (Combining Pairs of Samples)
# ------------------------------------------------------

# Co-assembly of AFW_S631 and BFW_S632
megahit -1 AFW_S631_trimmed_R1.fastq,BFW_S632_trimmed_R1.fastq -2 AFW_S631_trimmed_R2.fastq,BFW_S632_trimmed_R2.fastq -o AFW_BFW_coassembly \
  --k-min 31 --k-max 121 --k-step 10 --mem-flag 1 -m 429496729600 -t 20

# Co-assembly of BFW_S632 and BM_S633
megahit -1 BFW_S632_trimmed_R1.fastq,BM_S633_trimmed_R1.fastq -2 BFW_S632_trimmed_R2.fastq,BM_S633_trimmed_R2.fastq -o BFW_BM_coassembly \
  --k-min 31 --k-max 121 --k-step 10 --mem-flag 1 -m 429496729600 -t 20

# Co-assembly of AFW_S631 and BM_S633
megahit -1 AFW_S631_trimmed_R1.fastq,BM_S633_trimmed_R1.fastq -2 AFW_S631_trimmed_R2.fastq,BM_S633_trimmed_R2.fastq -o AFW_BM_coassembly \
  --k-min 31 --k-max 121 --k-step 10 --mem-flag 1 -m 429496729600 -t 20

