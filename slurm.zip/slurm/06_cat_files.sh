#!/bin/bash

#SBATCH --nodes=1                    # Number of nodes (usually 1 for metagenome assembly)
#SBATCH --ntasks=20                  # Number of tasks (CPU cores, one per sample if running in parallel)
#SBATCH --cpus-per-task=4            # Number of CPU cores per task (adjust according to your resource needs)
#SBATCH --mem=400G                   # Memory allocated for the job (adjust as needed)
#SBATCH --time=6-00:00:00            # Max runtime (DD-HH:MM:SS)
#SBATCH --nodelist=node005           # Specify the node
#SBATCH --partition=week-long-cpu    # Specify the partition

module load slurm
srun --pty bash
conda activate bin

cd ../trimmed_reads/

cat AFW_S631_trimmed_R1.fastq BFW_S632_trimmed_R1.fastq > AFW_BFW_coassembly_trimmed_R1.fastq
cat AFW_S631_trimmed_R2.fastq BFW_S632_trimmed_R2.fastq > AFW_BFW_coassembly_trimmed_R2.fastq

cat AFW_S631_trimmed_R1.fastq BM_S633_trimmed_R1.fastq > AFW_BM_coassembly_trimmed_R1.fastq
cat AFW_S631_trimmed_R2.fastq BM_S633_trimmed_R2.fastq > AFW_BM_coassembly_trimmed_R2.fastq

cat BM_S633_trimmed_R1.fastq BFW_S632_trimmed_R1.fastq > BFW_BM_coassembly_trimmed_R1.fastq
cat BM_S633_trimmed_R2.fastq BFW_S632_trimmed_R2.fastq > BFW_BM_coassembly_trimmed_R2.fastq

