#!/bin/bash

#SBATCH --nodes=1                    # Number of nodes (usually 1 for metagenome assembly)
#SBATCH --ntasks=20                  # Number of tasks (CPU cores, one per sample if running in parallel)
#SBATCH --cpus-per-task=4            # Number of CPU cores per task (adjust according to your resource needs)
#SBATCH --mem=400G                   # Memory allocated for the job (adjust as needed)
#SBATCH --time=6-00:00:00            # Max runtime (DD-HH:MM:SS)
#SBATCH --nodelist=node005           # Specify the node
#SBATCH --partition=week-long-cpu    # Specify the partition

module load slurm
srun --pty bash

cd ../

#!/bin/bash

# Define the source and target directories
ASSEMBLIES_DIR="assemblies"
TARGET_DIR="MAGs"

# Loop through each subdirectory in the assemblies directory
for ASSEMBLY_DIR in "$ASSEMBLIES_DIR"/*/; do
  # Get the assembly name (name of the subdirectory)
  ASSEMBLY_NAME=$(basename "$ASSEMBLY_DIR")
  
  # Find the target subdirectory containing MAGs
  MAG_DIR=$(find "$ASSEMBLY_DIR" -type d -name "${ASSEMBLY_NAME}_final.contigs_2500.fa.metabat-bins-*")
  
  if [ -d "$MAG_DIR" ]; then
    # Loop through each MAG file in the directory
    for MAG_FILE in "$MAG_DIR"/bin.*.fa; do
      # Get the bin name
      BIN_NAME=$(basename "$MAG_FILE")
      
      # Construct the new file name
      NEW_FILE_NAME="${ASSEMBLY_NAME}-${BIN_NAME}"
      
      # Copy and rename the MAG to the target directory
      cp "$MAG_FILE" "$TARGET_DIR/$NEW_FILE_NAME"
    done
  else
    echo "MAG directory not found for assembly: $ASSEMBLY_NAME"
  fi
done

echo "All MAGs have been copied and renamed to $TARGET_DIR."

