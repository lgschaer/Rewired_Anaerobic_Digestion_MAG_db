#!/bin/bash

#SBATCH --nodes=1                    # Number of nodes (usually 1 for metagenome assembly)
#SBATCH --ntasks=20                  # Number of tasks (CPU cores, one per sample if running in parallel)
#SBATCH --cpus-per-task=4            # Number of CPU cores per task (adjust according to your resource needs)
#SBATCH --mem=400G                   # Memory allocated for the job (adjust as needed)
#SBATCH --time=6-23:59:59            # Max runtime (DD-HH:MM:SS)
#SBATCH --nodelist=node002           # Specify the node
#SBATCH --partition=week-long-cpu    # Specify the partition

cd ../MAGs #/dRep_out/dereplicated_genomes

MAG_DIR="."
OUT_DIR="./Prokka_Out"

# Ensure output directory exists
mkdir -p "$OUTPUT_DIR"


# Loop over each .fa file in the MAG directory
for MAG in "$MAG_DIR"/*.fa; do
    # Check if any .fa files exist
    if [ ! -e "$MAG" ]; then
        echo "No .fa files found in $MAG_DIR. Exiting..."
        exit 1
    fi

    # Extract the base name (without path and extension)
    BASENAME=$(basename "$MAG" .fa)

    # Create a subdirectory for each MAG's results
    PROKKA_OUT="$OUT_DIR/$BASENAME"
    mkdir -p "$PROKKA_OUT"

    # Run Prokka
    echo "Processing $MAG with Prokka..."
    prokka --outdir "$PROKKA_OUT" --prefix "$BASENAME" "$MAG" --force
    
    # Check if Prokka completed successfully
    if [ $? -eq 0 ]; then
        echo "Prokka annotation completed for $BASENAME."
    else
        echo "Prokka annotation failed for $BASENAME. Check logs in $PROKKA_OUT."
    fi
done

echo "All MAGs processed!"



#prokka --cpus 20 *.fa
