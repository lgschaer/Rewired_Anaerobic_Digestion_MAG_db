#!/bin/bash

#SBATCH --nodes=1                    # Number of nodes (usually 1 for metagenome assembly)
#SBATCH --ntasks=20                  # Number of tasks (CPU cores, one per sample if running in parallel)
#SBATCH --cpus-per-task=4            # Number of CPU cores per task (adjust according to your resource needs)
#SBATCH --mem=1000G                   # Memory allocated for the job (adjust as needed)
#SBATCH --time=6-00:00:00            # Max runtime (DD-HH:MM:SS)
#SBATCH --nodelist=mnode001           # Specify the node
#SBATCH --partition=week-long-highmem    # Specify the partition

module load slurm
srun --pty bash
conda activate taxQC

#checkm2 assess -x fasta MAGs/ MAGs/SeqCenter_QC/ --force

export TMPDIR=/nfs/home/lschae/interactions_MG/slurm/tmp/
checkm2 predict --threads 20 -i ../MAGs/ -o ../MAGs/checkM_out/ -x fa --force --database_path /nfs/home/lschae/databases/CheckM2_database/uniref100.KO.1.dmnd

#gtdbtk classify_wf -x fa --genome_dir ../MAGs/ --out_dir ../gtdb_2.4.0 --cpus 20 --mash_db /nfs/home/lschae/miniconda3/envs/taxQC/share/release220/
