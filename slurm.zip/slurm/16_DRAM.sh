#!/bin/bash

#SBATCH --nodes=1                    # Number of nodes (usually 1 for metagenome assembly)
#SBATCH --ntasks=20                  # Number of tasks (CPU cores, one per sample if running in parallel)
#SBATCH --cpus-per-task=4            # Number of CPU cores per task (adjust according to your resource needs)
#SBATCH --mem=400G                   # Memory allocated for the job (adjust as needed)
#SBATCH --time=6-23:59:59            # Max runtime (DD-HH:MM:SS)
#SBATCH --nodelist=node007           # Specify the node
#SBATCH --partition=week-long-cpu    # Specify the partition

cd /nfs/home/lschae/miniconda3/envs/dram/bin/
#cd /nfs/home/lschae/interactions_MG/MAGs/galah_out/

DRAM.py annotate -i '/nfs/home/lschae/interactions_MG/MAGs/galah_out/*.fa' -o /nfs/home/lschae/interactions_MG/MAGs/galah_out/DRAM_annotation --low_mem_mode --threads 20

DRAM.py distill -i /nfs/home/lschae/interactions_MG/MAGs/galah_out/DRAM_annotation/annotations.tsv -o /nfs/home/lschae/interactions_MG/MAGs/galah_out/genome_summaries --trna_path /nfs/home/lschae/interactions_MG/MAGs/galah_out/DRAM_annotation/trnas.tsv --rrna_path /nfs/home/lschae/interactions_MG/MAGs/galah_out/DRAM_annotation/rrnas.tsv
