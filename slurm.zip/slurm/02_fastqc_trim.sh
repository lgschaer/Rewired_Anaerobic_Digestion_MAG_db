#!/bin/bash

#SBATCH --nodes=1                   # Number of nodes
#SBATCH --ntasks=3                  # Number of tasks (CPU cores)
#SBATCH --time=2-00:00:00           # Max runtime (DD-HH:MM:SS)
#SBATCH --nodelist=node003
#SBATCH --partition=week-long-cpu   # Specify the partition

module load slurm
srun --pty bash
conda init
conda activate trimQC

cd ../raw_reads/
mkdir fastqc_raw/

fastqc -o fastqc_raw/ *.fastq

# Loop over paired-end files in a directory
for R1 in *R1_001.fastq; do
    # Get the corresponding R2 file
    R2="${R1/_R1_001.fastq/_R2_001.fastq}"
    
    # Check if the R2 file exists
    if [[ -f "$R2" ]]; then
        # Define output file names
        OUT_R1="${R1/_R1_001.fastq/_trimmed_R1.fastq}"
        OUT_R2="${R2/_R2_001.fastq/_trimmed_R2.fastq}"

        # Run sickle pe
        sickle pe -f "$R1" -r "$R2" -t sanger -o "$OUT_R1" -p "$OUT_R2" -s "$R1.singles.fastq"
    else
        echo "No matching R2 file found for $R1"
    fi
done

mv *_trimmed* ../trimmed_reads/
cd ../trimmed_reads/

mkdir fastqc_trimmed/
fastqc -o fastqc_trimmed/ *fastq
