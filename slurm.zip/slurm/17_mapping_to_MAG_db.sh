#!/bin/bash

#SBATCH --nodes=1                    # Number of nodes (usually 1 for metagenome assembly)
#SBATCH --ntasks=20                  # Number of tasks (CPU cores, one per sample if running in parallel)
#SBATCH --cpus-per-task=4            # Number of CPU cores per task (adjust according to your resource needs)
#SBATCH --mem=400G                   # Memory allocated for the job (adjust as needed)
#SBATCH --time=6-23:59:59            # Max runtime (DD-HH:MM:SS)
#SBATCH --nodelist=node007           # Specify the node
#SBATCH --partition=week-long-cpu    # Specify the partition


cd /nfs/home/lschae/interactions_MG/MAGs/MAG_db

cat *fa > MAG_db_Jan-20-2025.fa

bbmap.sh -Xmx48G threads=20 overwrite=t ref=MAG_db_Jan-20-2025.fa in1=/nfs/home/lschae/interactions_MG/trimmed_reads/AFW_S631_trimmed_R1.fastq in2=/nfs/home/lschae/interactions_MG/trimmed_reads/AFW_S631_trimmed_R2.fastq outm=AFW_S631_trimmed_contigs_mapped_interleaved.fastq
bbmap.sh -Xmx48G threads=20 overwrite=t ref=MAG_db_Jan-20-2025.fa in1=/nfs/home/lschae/interactions_MG/trimmed_reads/BFW_S632_trimmed_R1.fastq in2=/nfs/home/lschae/interactions_MG/trimmed_reads/BFW_S632_trimmed_R2.fastq outm=BFW_S632_trimmed_contigs_mapped_interleaved.fastq
bbmap.sh -Xmx48G threads=20 overwrite=t ref=MAG_db_Jan-20-2025.fa in1=/nfs/home/lschae/interactions_MG/trimmed_reads/BM_S633_trimmed_R1.fastq in2=/nfs/home/lschae/interactions_MG/trimmed_reads/BM_S633_trimmed_R2.fastq outm=BM_S633_trimmed_contigs_mapped_interleaved.fastq


