#!/bin/bash

#SBATCH --nodes=1                    # Number of nodes (usually 1 for metagenome assembly)
#SBATCH --ntasks=64                  # Number of tasks (CPU cores, one per sample if running in parallel)
#SBATCH --cpus-per-task=4            # Number of CPU cores per task (adjust according to your resource needs)
#SBATCH --mem=400G                   # Memory allocated for the job (adjust as needed)
#SBATCH --time=6-23:59:59            # Max runtime (DD-HH:MM:SS)
#SBATCH --nodelist=mnode002           # Specify the node
#SBATCH --partition=week-long-highmem    # Specify the partition

module load slurm
srun --pty bash
conda activate bin

cd ../MAGs
dRep dereplicate dRep_out -p 20 -comp 50 -con 10 -g ./*fa
