#!/bin/bash

#SBATCH --nodes=1                    # Number of nodes (usually 1 for metagenome assembly)
#SBATCH --ntasks=20                  # Number of tasks (CPU cores, one per sample if running in parallel)
#SBATCH --cpus-per-task=4            # Number of CPU cores per task (adjust according to your resource needs)
#SBATCH --mem=400G                   # Memory allocated for the job (adjust as needed)
#SBATCH --time=6-00:00:00            # Max runtime (DD-HH:MM:SS)
#SBATCH --nodelist=node005           # Specify the node
#SBATCH --partition=week-long-cpu    # Specify the partition

module load slurm
srun --pty bash
conda activate bin

cd ../

# Set paths
PARENT_DIR=$(pwd)
ASSEMBLIES_DIR="${PARENT_DIR}/assemblies"
READS_DIR="${PARENT_DIR}/trimmed_reads"

# Loop over each subdirectory in assemblies/
for dir in ${ASSEMBLIES_DIR}/*pcnt_copy*; do
    if [ -d "$dir" ]; then
        ASSEMBLY_NAME=$(basename "$dir")
        CONTIGS_FILE="${dir}/final.contigs.fa"
        FILTERED_CONTIGS="${dir}/${ASSEMBLY_NAME}_final.contigs_2500.fa"
        SAM_FILE="${dir}/${ASSEMBLY_NAME}_mapped.sam"
        BAM_FILE="${dir}/${ASSEMBLY_NAME}_mapped.bam"
        SORTED_BAM="${dir}/${ASSEMBLY_NAME}_mapped.sorted.bam"
        FILTERED_BAM="${dir}/${ASSEMBLY_NAME}_mapped99per.sorted.bam"
        
        # Pull scaffolds >= 2500 bp
        echo "Filtering contigs for $ASSEMBLY_NAME..."
        pullseq -i "$CONTIGS_FILE" -m 2500 > "$FILTERED_CONTIGS"
        
        # Map trimmed reads to filtered contigs
        echo "Mapping reads for $ASSEMBLY_NAME..."
        bbmap.sh -Xmx48G threads=20 overwrite=t ref="$FILTERED_CONTIGS" \
            in1="${READS_DIR}/${ASSEMBLY_NAME}_sR1.fastq" \
            in2="${READS_DIR}/${ASSEMBLY_NAME}_sR2.fastq" \
            out="$SAM_FILE"
        
        # Convert SAM to BAM and sort
        echo "Converting SAM to BAM and sorting for $ASSEMBLY_NAME..."
        samtools view -@ 20 -bS "$SAM_FILE" > "$BAM_FILE"
        samtools sort -T "${dir}/${ASSEMBLY_NAME}_sorted" -o "$SORTED_BAM" "$BAM_FILE" -@ 20
        
        # Filter high-quality mappings
        echo "Filtering high-quality mappings for $ASSEMBLY_NAME..."
        reformat.sh -Xmx100g minidfilter=0.99 in="$SORTED_BAM" \
            out="$FILTERED_BAM" pairedonly=t primaryonly=t
        
        # Run MetaBAT2
        echo "Running MetaBAT2 for $ASSEMBLY_NAME..."
        runMetaBat.sh "$FILTERED_CONTIGS" "$FILTERED_BAM"
    fi
done

echo "Pipeline completed for all assemblies."

