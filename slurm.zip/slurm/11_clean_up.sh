#!/bin/bash

#SBATCH --nodes=1                    # Number of nodes (usually 1 for metagenome assembly)
#SBATCH --ntasks=20                  # Number of tasks (CPU cores, one per sample if running in parallel)
#SBATCH --cpus-per-task=4            # Number of CPU cores per task (adjust according to your resource needs)
#SBATCH --mem=400G                   # Memory allocated for the job (adjust as needed)
#SBATCH --time=6-00:00:00            # Max runtime (DD-HH:MM:SS)
#SBATCH --nodelist=node003           # Specify the node
#SBATCH --partition=week-long-cpu    # Specify the partition

module load slurm
srun --pty bash

cd ../assemblies/binned_assemblies/

#!/bin/bash

# Loop over all subdirectories in the current directory
for dir in */; do
    # Check if it is a directory
    if [ -d "$dir" ]; then
        echo "Processing directory: $dir"

        # Delete the specified files
        rm -f "${dir}"/*_final.contigs_2500_mapped.sam
        rm -f "${dir}"/*_final.contigs_2500_mapped.sorted.bam
        rm -f "${dir}"/*_final.contigs_2500_mapped99per.sorted.bam

        # Gzip the specific BAM file
        if [ -f "${dir}"/*_final.contigs_2500_mapped.bam ]; then
            gzip "${dir}"/*_final.contigs_2500_mapped.bam
        fi
    fi
done

echo "Processing complete."
