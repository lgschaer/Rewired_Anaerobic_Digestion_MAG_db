#!/bin/bash

#SBATCH --nodes=1                   # Number of nodes
#SBATCH --ntasks=3                  # Number of tasks (CPU cores)
#SBATCH --time=2-00:00:00           # Max runtime (DD-HH:MM:SS)
#SBATCH --nodelist=node003
#SBATCH --partition=week-long-cpu   # Specify the partition


cd ../trimmed_reads/
gunzip *1_trimmed_R1.fastq.gz
gunzip *2_trimmed_R1.fastq.gz
gunzip *3_trimmed_R1.fastq.gz
gunzip *1_trimmed_R2.fastq.gz
gunzip *2_trimmed_R2.fastq.gz
gunzip *3_trimmed_R2.fastq.gz
#cd ../
#tar -zcvf raw_reads.tar.gz raw_reads/
