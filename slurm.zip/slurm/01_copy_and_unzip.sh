#!/bin/bash

module load slurm

SBATCH --nodes=1
SBATCH --ntasks=1
SBATCH --time=14-00:00:00
SBATCH --mem=100gb
SBATCH --mail-type=BEGIN,END,FAIL
SBATCH --mail-user=laura.schaerer@colostate.edu

srun --pty bash

cp ../interactions_MG/Illumina_DNA_Reads/*fastq.gz ../interactions_MG/raw_reads/
cd ../interactions_MG/raw_reads/
gunzip *fastq.gz
